Welcome to the Re-Console Resources folder!
This includes everything that is loaded by default via the Re-Console_Resources resource pack, including the title screen assets.

Panorama's are from Cjnator38, all credit goes to him
